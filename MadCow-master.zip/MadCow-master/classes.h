
#ifndef CLASSES_H

class Tokens {
	public:
		enum YN {YES, NO, YNEND};
		enum TF {TRUE, FALSE, TFEND};
		enum DistType {CONSTANT, POISSON};
};	

#endif