#include "mealGroup.h"
#include <iostream>

MealGroup MealGroup;