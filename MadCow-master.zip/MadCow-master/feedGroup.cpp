#include "feedGroup.h"
#include <iostream>

FeedGroup FeedGroup;